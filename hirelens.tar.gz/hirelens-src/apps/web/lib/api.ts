import type { AnalysisResult, JobStatus } from "@hirelens/shared";

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:3000";

const POLL_INTERVAL_MS = 1500;
const MAX_POLLS = 60; // 90s: long enough to cover a Lambda cold start, short enough to give up

export class AnalysisError extends Error {}

async function readError(response: Response, fallback: string): Promise<string> {
  try {
    const body = await response.json();
    return typeof body?.error === "string" ? body.error : fallback;
  } catch {
    return fallback;
  }
}

/**
 * Submit, then poll. `onStatus` exists so the UI can say something truthful during the wait
 * rather than spinning silently for 20 seconds.
 */
export async function runAnalysis(
  resume: string,
  jd: string,
  onStatus?: (status: JobStatus) => void,
): Promise<AnalysisResult> {
  const submitted = await fetch(`${API_URL}/analyze`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ resume, jd }),
  }).catch(() => {
    throw new AnalysisError("Could not reach the service. Check your connection and try again.");
  });

  if (!submitted.ok) {
    throw new AnalysisError(
      await readError(submitted, "The service rejected that request. Check both documents."),
    );
  }

  const { jobId } = (await submitted.json()) as { jobId: string };

  for (let attempt = 0; attempt < MAX_POLLS; attempt++) {
    await new Promise((resolve) => setTimeout(resolve, POLL_INTERVAL_MS));

    const polled = await fetch(`${API_URL}/analyze/${jobId}`);
    if (!polled.ok) {
      throw new AnalysisError(await readError(polled, "Lost track of that analysis. Run it again."));
    }

    const data = (await polled.json()) as {
      status: JobStatus;
      result?: AnalysisResult;
      error?: string;
    };

    if (data.status === "done" && data.result) return data.result;
    if (data.status === "failed") {
      throw new AnalysisError(data.error ?? "The analysis did not finish. Try again.");
    }

    onStatus?.(data.status);
  }

  throw new AnalysisError("The analysis is taking longer than expected. Try again in a moment.");
}
