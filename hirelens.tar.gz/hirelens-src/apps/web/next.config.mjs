/** @type {import('next').NextConfig} */
const nextConfig = {
  // @hirelens/shared ships TypeScript source rather than a build step.
  transpilePackages: ["@hirelens/shared"],
};

export default nextConfig;
