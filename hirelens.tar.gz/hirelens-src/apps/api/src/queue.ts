import { Queue } from "bullmq";
import IORedis from "ioredis";
import { env } from "./env.js";

// BullMQ requires maxRetriesPerRequest: null on the connection it blocks on.
export const connection = new IORedis(env.REDIS_URL, { maxRetriesPerRequest: null });

export const ANALYSIS_QUEUE = "analysis";

export const analysisQueue = new Queue(ANALYSIS_QUEUE, { connection });
