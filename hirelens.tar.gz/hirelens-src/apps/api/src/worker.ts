import { Worker } from "bullmq";
import type { AnalyzeRequest } from "@hirelens/shared";
import { env } from "./env.js";
import { prisma } from "./db.js";
import { connection, ANALYSIS_QUEUE } from "./queue.js";
import { normalizeAnalysis } from "./result.js";

// A cold Lambda has to pull the image and load a ~2GB model before it answers (Phase 8.8),
// so the timeout here is generous on purpose. The queue is what keeps the API responsive.
const INFERENCE_TIMEOUT_MS = 90_000;

const worker = new Worker<AnalyzeRequest>(
  ANALYSIS_QUEUE,
  async (job) => {
    const { resume, jd } = job.data;

    const response = await fetch(`${env.ML_SERVICE_URL}/infer`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ resume, jd }),
      signal: AbortSignal.timeout(INFERENCE_TIMEOUT_MS),
    });

    if (!response.ok) {
      throw new Error(`Inference service returned ${response.status}`);
    }

    const result = normalizeAnalysis(await response.json());

    await prisma.analysis.create({
      data: {
        resumeText: resume,
        jdText: jd,
        fitScore: result.fitScore,
        gaps: result.gaps,
        questions: result.interviewQuestions,
      },
    });

    return result;
  },
  { connection, concurrency: 1 },
);

worker.on("failed", (job, err) => {
  console.error(`[worker] job ${job?.id} failed: ${err.message}`);
});

worker.on("completed", (job) => {
  console.log(`[worker] job ${job.id} completed`);
});

for (const signal of ["SIGINT", "SIGTERM"] as const) {
  process.on(signal, async () => {
    await worker.close();
    await prisma.$disconnect();
    process.exit(0);
  });
}
