import "dotenv/config";
import { z } from "zod";

const EnvSchema = z.object({
  DATABASE_URL: z.string().min(1),
  REDIS_URL: z.string().default("redis://localhost:6379"),
  ML_SERVICE_URL: z.string().default("http://localhost:8000"),
  PORT: z.coerce.number().default(3000),
  CORS_ORIGIN: z.string().default("*"),
});

const parsed = EnvSchema.safeParse(process.env);

if (!parsed.success) {
  const missing = parsed.error.issues.map((i) => i.path.join(".")).join(", ");
  throw new Error(`Environment is not configured: ${missing}. Copy .env.example to .env.`);
}

export const env = parsed.data;
