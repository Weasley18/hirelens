import type { FastifyInstance } from "fastify";
import { AnalyzeRequestSchema } from "@hirelens/shared";
import { analysisQueue } from "../queue.js";
import { mapJobState } from "../result.js";

export async function analyzeRoutes(app: FastifyInstance) {
  app.post("/analyze", async (request, reply) => {
    const parsed = AnalyzeRequestSchema.safeParse(request.body);

    if (!parsed.success) {
      return reply.status(400).send({
        error: "Check the resume and job description",
        details: parsed.error.issues.map((i) => ({
          field: i.path.join("."),
          message: i.message,
        })),
      });
    }

    const job = await analysisQueue.add("analyze", parsed.data, {
      removeOnComplete: { age: 3600, count: 200 },
      removeOnFail: { age: 3600, count: 200 },
    });

    return reply.status(202).send({ jobId: job.id });
  });

  app.get<{ Params: { jobId: string } }>("/analyze/:jobId", async (request, reply) => {
    const job = await analysisQueue.getJob(request.params.jobId);

    if (!job) {
      return reply.status(404).send({ error: "That analysis has expired. Run it again." });
    }

    const status = mapJobState(await job.getState());

    if (status === "done") {
      return { status, result: job.returnvalue };
    }
    if (status === "failed") {
      return reply.status(200).send({
        status,
        error: job.failedReason ?? "The analysis did not finish. Try again.",
      });
    }

    return { status };
  });
}
