import Fastify from "fastify";
import cors from "@fastify/cors";
import rateLimit from "@fastify/rate-limit";
import { env } from "./env.js";
import { analyzeRoutes } from "./routes/analyze.js";
import { statsRoutes } from "./routes/stats.js";

const app = Fastify({ logger: true, bodyLimit: 1_048_576 });

await app.register(cors, { origin: env.CORS_ORIGIN === "*" ? true : env.CORS_ORIGIN.split(",") });

// The demo link is public and every analysis costs Lambda time, so cap it per IP.
await app.register(rateLimit, {
  max: 20,
  timeWindow: "1 minute",
  errorResponseBuilder: () => ({
    error: "Too many analyses from this address. Wait a minute and try again.",
  }),
});

app.get("/health", async () => ({ status: "ok" }));

await app.register(analyzeRoutes);
await app.register(statsRoutes);

try {
  await app.listen({ port: env.PORT, host: "0.0.0.0" });
} catch (err) {
  app.log.error(err);
  process.exit(1);
}
