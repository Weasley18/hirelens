import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { AnalyzeRequestSchema, AnalysisResultSchema } from "@hirelens/shared";
import { normalizeAnalysis, mapJobState, ModelOutputError } from "../src/result.ts";

const fixture = JSON.parse(
  readFileSync(
    fileURLToPath(new URL("../../../packages/shared/fixtures/sample-analysis.json", import.meta.url)),
    "utf8",
  ),
);

const validResume = "Backend engineer with six years building Node services. ".repeat(4);
const validJd = "We are hiring a senior backend engineer to own our payments platform. ".repeat(3);

describe("AnalyzeRequestSchema", () => {
  test("accepts a normal resume and job description", () => {
    const parsed = AnalyzeRequestSchema.safeParse({ resume: validResume, jd: validJd });
    assert.equal(parsed.success, true);
  });

  test("rejects a resume that is too short to analyse", () => {
    const parsed = AnalyzeRequestSchema.safeParse({ resume: "hire me", jd: validJd });
    assert.equal(parsed.success, false);
  });

  test("rejects a document pasted far over the input cap", () => {
    const parsed = AnalyzeRequestSchema.safeParse({ resume: "x".repeat(50_000), jd: validJd });
    assert.equal(parsed.success, false);
  });

  test("rejects a missing job description", () => {
    const parsed = AnalyzeRequestSchema.safeParse({ resume: validResume });
    assert.equal(parsed.success, false);
  });
});

describe("shared schema parity", () => {
  test("the shared fixture satisfies the zod schema", () => {
    const parsed = AnalysisResultSchema.safeParse(fixture);
    assert.equal(parsed.success, true, JSON.stringify(parsed.error?.issues));
  });
});

describe("normalizeAnalysis", () => {
  test("passes through a well-formed analysis", () => {
    const result = normalizeAnalysis(structuredClone(fixture));
    assert.equal(result.fitScore, 74);
    assert.equal(result.gaps.length, 3);
  });

  test("coerces a score the model emitted as a string", () => {
    const result = normalizeAnalysis({ ...structuredClone(fixture), fitScore: "82" });
    assert.equal(result.fitScore, 82);
  });

  test("rounds and clamps a score outside 0-100", () => {
    assert.equal(normalizeAnalysis({ ...structuredClone(fixture), fitScore: 104 }).fitScore, 100);
    assert.equal(normalizeAnalysis({ ...structuredClone(fixture), fitScore: 81.6 }).fitScore, 82);
  });

  test("treats a missing gaps array as no gaps found", () => {
    const raw = structuredClone(fixture);
    delete raw.gaps;
    assert.deepEqual(normalizeAnalysis(raw).gaps, []);
  });

  test("rejects output missing required content instead of inventing it", () => {
    const raw = structuredClone(fixture);
    delete raw.strengths;
    assert.throws(() => normalizeAnalysis(raw), ModelOutputError);
  });

  test("rejects an unknown severity value", () => {
    const raw = structuredClone(fixture);
    raw.gaps[0].severity = "catastrophic";
    assert.throws(() => normalizeAnalysis(raw), ModelOutputError);
  });

  test("surfaces the inference service's own error payload", () => {
    assert.throws(
      () => normalizeAnalysis({ error: "model produced invalid JSON", raw: "{fitScore:" }),
      /invalid JSON/,
    );
  });

  test("rejects a non-object response", () => {
    assert.throws(() => normalizeAnalysis("not json"), ModelOutputError);
  });
});

describe("mapJobState", () => {
  test("maps BullMQ states to what the frontend polls for", () => {
    assert.equal(mapJobState("completed"), "done");
    assert.equal(mapJobState("failed"), "failed");
    assert.equal(mapJobState("active"), "active");
    assert.equal(mapJobState("waiting"), "queued");
    assert.equal(mapJobState(undefined), "queued");
  });
});
