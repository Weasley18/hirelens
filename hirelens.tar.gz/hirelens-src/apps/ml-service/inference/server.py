"""The inference microservice (Phase 7.2).

One job: given a resume and a JD, retrieve context, run the model, return validated JSON.
It holds no other state and owns no other route, which is what makes it deployable to Lambda
unchanged while the Fastify API stays on a normal always-on host.
"""

from __future__ import annotations

import logging
import time

from fastapi import FastAPI
from pydantic import BaseModel, Field

from common import validate_analysis
from inference.llm import BACKEND, generate_analysis
from inference.skills import extract_skills, jd_only_skills

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("hirelens")

app = FastAPI(title="HireLens inference")


class AnalyzeRequest(BaseModel):
    resume: str = Field(min_length=80, max_length=20000)
    jd: str = Field(min_length=60, max_length=20000)


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "backend": BACKEND}


@app.post("/infer")
def infer(req: AnalyzeRequest) -> dict:
    started = time.monotonic()

    # Gaps first: the questions that probe something missing are the ones the model is
    # least able to invent well, so they get first claim on the context budget.
    gaps = jd_only_skills(req.resume, req.jd, limit=3)
    present = extract_skills(req.resume, req.jd, limit=6)
    skills = list(dict.fromkeys(gaps + present))

    chunks: list[dict] = []
    try:
        from rag.retrieve import retrieve_for_skills

        chunks = retrieve_for_skills(skills)
    except Exception as exc:  # noqa: BLE001
        # No knowledge base is a worse answer, not a failed request.
        log.warning("retrieval unavailable, continuing without context: %s", exc)

    try:
        analysis = generate_analysis(req.resume, req.jd, chunks)
    except ValueError as exc:
        log.error("unparseable model output: %s", exc)
        return {"error": "model produced invalid JSON", "raw": str(exc)}

    issues = validate_analysis(analysis)
    if issues:
        log.error("model output failed schema: %s", issues[:3])
        return {"error": f"model output did not match the schema: {issues[0]}", "raw": analysis}

    log.info(
        "analysed in %.1fs (skills=%s, chunks=%d, backend=%s)",
        time.monotonic() - started, ",".join(skills[:4]), len(chunks), BACKEND,
    )
    return analysis
