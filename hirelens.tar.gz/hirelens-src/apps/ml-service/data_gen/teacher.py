"""The teacher model used to generate training data (Phase 3).

Only used locally, only during data generation. Production never calls this — that is the
whole point of distilling into a small model. Swapping providers means replacing the body
of `call_teacher` and nothing else.
"""

from __future__ import annotations

import json
import os
import time

from common import extract_json, load_schema

MODEL = os.environ.get("TEACHER_MODEL", "gemini-2.0-flash")
_RETRIES = 3

ANALYSIS_SYSTEM_PROMPT = """You are a senior technical recruiter with a strong engineering background.

Given a resume and a job description, output ONLY valid JSON matching this schema:

{schema}

Rules:
- Ground every claim in the actual resume text. Never credit a skill that is not there.
- A gap is something the job description asks for that the resume does not evidence.
- fitScore must be consistent with the gaps: severe gaps mean a score well below 80.
- Interview questions must be specific to this candidate's actual experience, not generic.
- Output the JSON object and nothing else. No prose, no markdown fences."""


def _client():
    import google.generativeai as genai

    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY is not set — see .env.example")
    genai.configure(api_key=api_key)
    return genai.GenerativeModel(MODEL)


def call_teacher(prompt: str, temperature: float = 0.7) -> str:
    """One call to the teacher model, with retries for transient/rate-limit failures."""
    model = _client()
    last_error: Exception | None = None

    for attempt in range(_RETRIES):
        try:
            response = model.generate_content(
                prompt,
                generation_config={"temperature": temperature, "max_output_tokens": 2048},
            )
            return response.text
        except Exception as exc:  # noqa: BLE001 - free tiers fail in many shapes
            last_error = exc
            time.sleep(2**attempt)

    raise RuntimeError(f"teacher model failed after {_RETRIES} attempts: {last_error}")


def analyse_pair(resume: str, jd: str) -> dict:
    """Produce one training label: the analysis JSON for a (resume, JD) pair."""
    system = ANALYSIS_SYSTEM_PROMPT.format(schema=json.dumps(load_schema(), indent=2))
    prompt = f"{system}\n\nRESUME:\n{resume}\n\nJOB DESCRIPTION:\n{jd}"
    return extract_json(call_teacher(prompt, temperature=0.4))
