"""Step 2 of Phase 3: label each pair with the teacher model.

Run: python -m data_gen.generate
Reads data/pairs.jsonl, writes data/dataset_raw.jsonl.
"""

from __future__ import annotations

import argparse
import time
from pathlib import Path

from common import read_jsonl, write_jsonl
from data_gen.teacher import analyse_pair

PAIRS = Path("data/pairs.jsonl")
OUT = Path("data/dataset_raw.jsonl")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sleep", type=float, default=1.0)
    args = parser.parse_args()

    pairs = read_jsonl(PAIRS)
    done = read_jsonl(OUT) if OUT.exists() else []
    seen = {row["resume"][:200] for row in done}

    for i, pair in enumerate(pairs):
        if pair["resume"][:200] in seen:
            continue
        try:
            output = analyse_pair(pair["resume"], pair["jd"])
            done.append({"resume": pair["resume"], "jd": pair["jd"], "output": output,
                         "meta": pair.get("meta", {})})
        except Exception as exc:  # noqa: BLE001
            print(f"  skipped {i}: {exc}")
            continue

        if len(done) % 20 == 0:
            write_jsonl(OUT, done)
            print(f"  {len(done)}/{len(pairs)} labelled")
        time.sleep(args.sleep)

    write_jsonl(OUT, done)
    print(f"wrote {len(done)} examples to {OUT}")


if __name__ == "__main__":
    main()
