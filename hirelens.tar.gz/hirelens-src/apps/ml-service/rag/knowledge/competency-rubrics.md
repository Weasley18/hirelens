# Engineering competency expectations by level

## Junior engineer, scope and autonomy

Expect ownership of well-defined tasks with review, not of design. The signal to look for is
learning rate: can they describe something they got wrong recently and what changed as a
result? Questions should test fundamentals and curiosity rather than architecture. It is
reasonable for a junior candidate to have no production incident stories; it is not reasonable
for them to have no opinions about code they have read.

## Junior engineer, what to ask

Ask them to walk through a project they built and why they made a specific choice in it.
Follow the answer down one level — if they used a framework, ask what it did for them.
Ask how they tested it and how they knew it worked. Depth on one small thing they actually
built tells you more than breadth across things they configured.

## Mid-level engineer, scope and autonomy

Expect independent ownership of a feature or service end to end, including its failure modes
and its rollout. The distinguishing signal from junior is anticipation: they describe what
could go wrong before being asked. Expect them to have opinions on testing and code review,
and to be able to disagree with a past decision of their own.

## Mid-level engineer, what to ask

Ask for a technical decision they made where the alternatives were genuinely close, and what
tipped it. Ask what they would change about a system they built if they started again. Probe
one production incident: what they saw first, what they tried, what actually fixed it. Vague
answers at this level usually mean the work was owned by someone else.

## Senior engineer, scope and autonomy

Expect influence beyond their own code: design that others build on, mentoring, and judgement
about what not to build. The clearest signal is a story about scoping something down or
arguing against work. Expect them to describe tradeoffs in terms of cost to the team and the
business, not only technical elegance.

## Senior engineer, what to ask

Ask about a time they changed their mind after pushback, and a time they held their position.
Ask how they brought a junior engineer up to speed and what they did differently the second
time. For architecture, ask what they would do with half the time or half the team, which
tests prioritisation rather than knowledge.

## Reading a resume for level, not years

Years of experience predict level weakly. Better signals: the size of the thing they owned,
whether they describe decisions or tasks, whether outcomes are quantified, and whether their
scope grew across roles. Three years of increasing ownership beats eight years of the same
feature work, and a resume that lists technologies without outcomes usually hides the latter.

## Career changers and non-traditional backgrounds

Assess the relevant work, not the path to it. A bootcamp graduate with one deeply built
project can be stronger than a CS graduate with none. Ask what they did before and what
transfers — support, operations, teaching and finance all produce genuinely useful engineering
instincts. The fair probe is depth on what they have built, at the same standard applied to
anyone else, without discounting the absence of a traditional credential.

## Employment gaps

A gap is not a signal about ability. Ask what they were doing and whether they kept building,
then move on. The relevant question is whether their skills are current, which is answered by
their recent work rather than by the gap itself.
