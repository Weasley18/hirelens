# Writing good interview questions

## Anchor the question in the candidate's own work

A question that names something from the resume — a specific system, migration, or number —
is harder to answer from memorised preparation and produces a more informative answer. "You
partitioned a 40 million row table; how did you choose the key?" beats "explain database
partitioning." Generic questions test recall; anchored questions test whether the claimed
experience is real.

## Probing a gap fairly

When the job description requires something the resume does not show, the useful question is
not trivia about the missing technology. Ask what they expect to be different, what they
would want to learn first, or how a nearby thing they have done relates. This measures
transferable reasoning and learning approach, which is what actually predicts whether the gap
closes, while a trivia question only confirms the gap you already knew about.

## Follow-up depth beats question count

One question followed three levels down reveals more than five surface questions. Plan the
follow-ups: after the what, ask the why, then ask what they would do differently. Candidates
who prepared an answer usually have not prepared the third follow-up.

## Ask about failure, specifically

"Tell me about something that broke" elicits more signal than "tell me about a success",
because the story cannot be borrowed from the team as easily. Look for specificity about what
they personally did, and for a change that outlasted the incident.

## Calibrating difficulty to the role

A junior question asks whether they understand what they used. A mid-level question asks
whether they can weigh two reasonable options. A senior question asks what they would not
build, and why. Asking a senior architecture question of a junior candidate measures nothing
except confidence.

## Questions to avoid

Avoid puzzles with a single trick, questions that reward memorised trivia over reasoning, and
anything the interviewer cannot answer well themselves. Avoid questions whose answer depends
on knowing one company's internal conventions. Avoid asking a candidate to guess what you are
thinking; if there is one right answer and no reasoning path to it, it is a quiz, not an
interview.

## Quantified claims deserve follow-up

When a resume says latency dropped by 85% or a system handled a million users, ask what was
measured, over what period, and what their specific contribution was. This is not scepticism
for its own sake — the follow-up separates a real optimisation story from a number inherited
from a team dashboard, and a candidate who did the work enjoys the question.
